<?php


	
    	echo "
		
		  <div class='masthead'>
    <h3 class='text-muted'>Project name</h3>
    <ul class='nav nav-justified'>
      <li ><a href='index.php'>Home</a></li>
      <li ><a href='member.php'>Member</a></li>
      <li ><a href='company.php'>Company</a></li>
      <li ><a href='search_company.php'>Search Company</a></li>
      <li><a href='search_member.php'>Search Member</a></li>
      <li><a href='user_management.php'>User Management</a></li>
    </ul>
  </div>";
         	
	
	
?>

